package com.a3x3conect.validationtutorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;

public class MainActivity extends AppCompatActivity {

    EditText fname,lname,email,phno,pass,cnfpass;
    Button submit;
    AwesomeValidation awesomeValidation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);


        updateUI();
    }

    private void updateUI() {

        fname =(EditText)findViewById(R.id.fname);
        lname =(EditText)findViewById(R.id.lname);
        email =(EditText)findViewById(R.id.email);
        pass =(EditText)findViewById(R.id.pass);
        cnfpass =(EditText)findViewById(R.id.cnfpass);
        phno =(EditText)findViewById(R.id.phno);
        submit =(Button)findViewById(R.id.submit);

        String regexPassword = "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])(?=.*[~`!@#\\$%\\^&\\*\\(\\)\\-_\\+=\\{\\}\\[\\]\\|\\;:\"<>,./\\?]).{8,}";
        awesomeValidation.addValidation(MainActivity.this,R.id.fname, "[a-zA-Z\\s]+",R.string.fnameerr);
        awesomeValidation.addValidation(MainActivity.this,R.id.lname,"[a-zA-Z\\s]+",R.string.lnameerr);
        awesomeValidation.addValidation(MainActivity.this,R.id.email,android.util.Patterns.EMAIL_ADDRESS,R.string.emailerr);
        awesomeValidation.addValidation(MainActivity.this,R.id.phno, RegexTemplate.TELEPHONE,R.string.phoneerr);
        awesomeValidation.addValidation(MainActivity.this,R.id.pass,regexPassword,R.string.passerr);
        awesomeValidation.addValidation(MainActivity.this,R.id.cnfpass,R.id.pass,R.string.cnfpasserr);



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (awesomeValidation.validate()){

                    Toast.makeText(MainActivity.this, "Data Received Succesfully", Toast.LENGTH_SHORT).show();
                }

                else

                {
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}
